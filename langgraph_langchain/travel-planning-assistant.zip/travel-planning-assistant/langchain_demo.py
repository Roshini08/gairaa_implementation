"""
langchain_demo.py
------------------
A small, INDEPENDENT demonstration of LangChain with no LangGraph involved.

Purpose:
    Show the simplest possible LangChain flow so it can be explained on
    its own, before the LangGraph pieces are introduced:

        User Query -> ChatPromptTemplate -> ChatOllama -> Response

Run directly with:  python langchain_demo.py
"""

from langchain_core.prompts import ChatPromptTemplate
from langchain_ollama import ChatOllama

MODEL_NAME = "qwen2.5:3b-instruct"


def build_simple_chain():
    """
    Builds and returns a LangChain "Runnable" chain: prompt | llm.

    ChatPromptTemplate:
        - Defines the message(s) sent to the model.
        - "{query}" is a variable slot filled in at invoke() time.
        - It receives: a dict of variables (e.g. {"query": "..."})
        - It returns: a formatted list of chat messages.

    ChatOllama:
        - LangChain's wrapper around a locally running Ollama server.
        - It receives: the formatted messages from the prompt.
        - It returns: an AIMessage containing the model's text response.
        - Communication path: ChatOllama -> local HTTP call to Ollama
          (http://localhost:11434 by default) -> the qwen2.5:3b-instruct
          model weights loaded in Ollama -> generated text -> back to
          ChatOllama -> back to Python. This entire round trip is LOCAL,
          no external network call, no API key.

    The "|" operator:
        - This is LangChain's "Runnable" composition operator.
        - `prompt | llm` builds a chain where the OUTPUT of `prompt`
          becomes the INPUT of `llm`. It does not run anything yet --
          it just wires the two pieces together into one callable object.
    """
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                "You are a concise travel assistant. Answer in 2-3 sentences.",
            ),
            ("human", "{query}"),
        ]
    )

    llm = ChatOllama(model=MODEL_NAME, temperature=0.3)

    # This single line creates the chain. Nothing runs until .invoke() is called.
    chain = prompt | llm
    return chain


def run_demo():
    chain = build_simple_chain()

    query = "What are 3 must-see attractions in Chennai?"

    # invoke():
    #   - Receives a dict of prompt variables: {"query": query}
    #   - Internally: fills the prompt template -> sends messages to ChatOllama
    #     -> ChatOllama calls the local Ollama server -> model generates text
    #     -> result is wrapped back into an AIMessage
    #   - Returns: an AIMessage object. Its .content field holds the text.
    response = chain.invoke({"query": query})

    print("=== LangChain-only demo ===")
    print(f"User query : {query}")
    print(f"LLM response: {response.content}")


if __name__ == "__main__":
    run_demo()
