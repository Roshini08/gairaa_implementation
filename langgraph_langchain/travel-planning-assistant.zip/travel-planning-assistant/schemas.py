"""
schemas.py
----------
Typed data structures shared by the LangGraph workflow.

Why this file exists:
    LangGraph needs a concrete "shape" for the state that flows between
    nodes. TravelState (a TypedDict) IS that shape. Every node function
    receives a dict matching this shape and returns a partial dict of
    updates, which LangGraph merges back into the running state.

    TravelClassification (a Pydantic model) is used ONLY to validate and
    parse the JSON that the LLM produces when classifying a request. It
    is not the graph state itself -- it is a helper for the analysis node.
"""

from typing import TypedDict, Literal, Optional
from pydantic import BaseModel, Field

# Allowed categorical values. Keeping these as Literal types means
# type checkers (and humans reading the code) know the exact valid set.
TripType = Literal["family", "budget", "business", "leisure"]
BudgetLevel = Literal["low", "medium", "high"]


class TravelClassification(BaseModel):
    """
    Structured output we ask the LLM to produce during analysis.

    Why Pydantic here specifically:
        The LLM returns raw text. Pydantic gives us validation
        (e.g. trip_type must be one of the four allowed values) and a
        clear error if the model returns something malformed, so we can
        fail predictably instead of silently propagating garbage state.
    """

    destination: str = Field(description="City or region the user wants to visit")
    trip_type: TripType = Field(description="One of: family, budget, business, leisure")
    duration: str = Field(description="Trip length as stated or implied, e.g. '3 days'")
    traveler_type: str = Field(description="Who is travelling, e.g. family, couple, solo, colleagues")
    budget_level: BudgetLevel = Field(description="One of: low, medium, high")
    reasoning: str = Field(description="One short sentence on why this classification was chosen")


class TravelState(TypedDict):
    """
    The single state object that flows through every LangGraph node.

    Field-by-field flow:
        user_query      -> set once, at the start, never changes
        destination     -> filled by the analysis node
        trip_type       -> filled by the analysis node, read by the router
        duration        -> filled by the analysis node
        traveler_type    -> filled by the analysis node
        budget_level    -> filled by the analysis node
        reasoning       -> filled by the analysis node (explains the classification)
        final_plan      -> filled by whichever handler node the router selects
        error           -> set if something goes wrong, so app.py can report it cleanly
    """

    user_query: str
    destination: Optional[str]
    trip_type: Optional[TripType]
    duration: Optional[str]
    traveler_type: Optional[str]
    budget_level: Optional[BudgetLevel]
    reasoning: Optional[str]
    final_plan: Optional[str]
    error: Optional[str]
