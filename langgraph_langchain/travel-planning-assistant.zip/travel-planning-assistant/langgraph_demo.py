"""
langgraph_demo.py
------------------
A small, INDEPENDENT demonstration of LangGraph with NO LLM involved.

Purpose:
    Show the core orchestration concepts -- typed state, nodes, edges,
    conditional routing, compile(), invoke() -- in total isolation, using
    trivial logic (string checks) instead of an LLM call. This is
    deliberately LLM-free so it always runs, even if Ollama is offline,
    and so the audience's attention stays on the GRAPH mechanics, not
    on the AI output.

    Concept mapped 1:1 onto the real workflow later in graph.py:
        START -> classify -> (conditional) -> handler -> END

Run directly with:  python langgraph_demo.py
"""

from typing import TypedDict, Literal
from langgraph.graph import StateGraph, START, END


class ToyState(TypedDict):
    """Minimal typed state: just enough fields to show data flowing."""
    text: str
    category: str
    result: str


def classify_node(state: ToyState) -> dict:
    """
    A NODE is just a plain Python function.
    Receives: the current state (a dict matching ToyState).
    Returns: a partial dict of fields to update in the state.
    LangGraph merges this returned dict into the running state
    before passing it to the next node.
    """
    text = state["text"].lower()
    category = "question" if "?" in text else "statement"
    return {"category": category}


def route_by_category(state: ToyState) -> Literal["question_handler", "statement_handler"]:
    """
    A CONDITIONAL ROUTER function.
    Receives: the current state.
    Returns: the NAME of the next node to run (a string key), not state.
    This is what add_conditional_edges() calls to decide where to go.
    """
    if state["category"] == "question":
        return "question_handler"
    return "statement_handler"


def question_handler(state: ToyState) -> dict:
    return {"result": f"Handled as a QUESTION: {state['text']}"}


def statement_handler(state: ToyState) -> dict:
    return {"result": f"Handled as a STATEMENT: {state['text']}"}


def build_toy_graph():
    # StateGraph(ToyState): declares that every node in this graph
    # reads/writes a dict shaped like ToyState.
    builder = StateGraph(ToyState)

    # add_node(name, fn): registers a function under a string name.
    # Receives: a unique node name + a callable.
    # Returns: nothing (mutates the builder).
    builder.add_node("classify", classify_node)
    builder.add_node("question_handler", question_handler)
    builder.add_node("statement_handler", statement_handler)

    # add_edge(a, b): unconditional transition -- always go from a to b.
    builder.add_edge(START, "classify")

    # add_conditional_edges(source_node, router_fn, mapping):
    # Receives: the node to branch FROM, a function that inspects state
    #           and returns a key, and a mapping of key -> next node name.
    # Returns: nothing (mutates the builder).
    builder.add_conditional_edges(
        "classify",
        route_by_category,
        {
            "question_handler": "question_handler",
            "statement_handler": "statement_handler",
        },
    )

    builder.add_edge("question_handler", END)
    builder.add_edge("statement_handler", END)

    # compile(): validates the graph (checks every node is reachable,
    # every edge points somewhere real) and returns an executable object.
    return builder.compile()


def run_demo():
    graph = build_toy_graph()

    for sample_text in ["Where should I go in Goa?", "I like beaches."]:
        # graph.invoke(): runs the compiled graph start to finish.
        # Receives: the initial state dict.
        # Returns: the final state dict after all nodes have run.
        final_state = graph.invoke({"text": sample_text, "category": "", "result": ""})
        print("=== LangGraph-only demo ===")
        print(f"Input   : {sample_text}")
        print(f"Category: {final_state['category']}")
        print(f"Result  : {final_state['result']}\n")


if __name__ == "__main__":
    run_demo()
